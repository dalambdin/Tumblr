//
//  ComposeViewController.swift
//  Week4Tumblr
//
//  Created by Lambdin, Daniel on 4/25/16.
//  Copyright © 2016 Daniel Lambdin. All rights reserved.
//

import UIKit

class ComposeViewController: UIViewController {

   
    @IBOutlet weak var nevermindButton: UIButton!

    @IBOutlet weak var buttonA: UIButton!
    @IBOutlet weak var buttonB: UIButton!
    @IBOutlet weak var buttonC: UIButton!
    @IBOutlet weak var buttonD: UIButton!
    @IBOutlet weak var buttonE: UIButton!
    @IBOutlet weak var buttonF: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let blueColor = UIColor(red: 41/255.0, green: 54/255.0, blue: 73/255.0, alpha: 0.6)
        view.backgroundColor = blueColor


    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    
    @IBAction func didPressNevermind(sender: AnyObject) {
        
        dismissViewControllerAnimated(true, completion: {})
        
    }
    
    override func viewWillAppear(animated: Bool) {
       
        buttonA.frame = CGRectOffset(buttonA.frame, 0, 1000);
        buttonB.frame = CGRectOffset(buttonB.frame, 0, 1000);
        buttonC.frame = CGRectOffset(buttonC.frame, 0, 1000);
        buttonD.frame = CGRectOffset(buttonD.frame, 0, 1000);
        buttonE.frame = CGRectOffset(buttonE.frame, 0, 1000);
        buttonF.frame = CGRectOffset(buttonF.frame, 0, 1000);
    
    }
    
    
    override func viewDidAppear(animated: Bool) {
        
        UIView.animateWithDuration(0.6, delay: 0.1, options: .CurveEaseInOut, animations: {
            
            self.buttonA.frame = CGRectOffset(self.buttonA.frame, 0, -1000);

            }, completion: nil)
        
        UIView.animateWithDuration(0.6, delay: 0.0, options: .CurveEaseInOut, animations: {
            
            self.buttonB.frame = CGRectOffset(self.buttonB.frame, 0, -1000);
            
            }, completion: nil)
        
        UIView.animateWithDuration(0.6, delay: 0.2, options: .CurveEaseInOut, animations: {
            
            self.buttonC.frame = CGRectOffset(self.buttonC.frame, 0, -1000);
            
            }, completion: nil)
        
        UIView.animateWithDuration(0.6, delay: 0.3, options: .CurveEaseInOut, animations: {
            
            self.buttonD.frame = CGRectOffset(self.buttonD.frame, 0, -1000);
            
            }, completion: nil)
        
        UIView.animateWithDuration(0.6, delay: 0.2, options: .CurveEaseInOut, animations: {
            
            self.buttonE.frame = CGRectOffset(self.buttonE.frame, 0, -1000);
            
            }, completion: nil)
        
        UIView.animateWithDuration(0.6, delay: 0.4, options: .CurveEaseInOut, animations: {
            
            self.buttonF.frame = CGRectOffset(self.buttonF.frame, 0, -1000);
            
            }, completion: nil)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
